import sys
import os.path
import shutil
import time
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import urllib, json


import xbmcaddon
import xbmc

import datetime
import zipfile

import codecs


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])


xbmcplugin.setContent(addon_handle, 'movies')
my_addon = xbmcaddon.Addon()
addon_name = my_addon.getAddonInfo('name');
mode = args.get('mode', None)

PORTAL = "http://smashstreams.ddns.net:9090"
PORTAL_ADDR = PORTAL+"/api/device/?"

ALLOW_CACHE = 1
MAX_PROGRAMME = 4               #MAX PROGRAMME TO SHOW ON DESCRIPTION



LOGOS_DIR = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.'+addon_name+'/resources/logos', ''))
CACHE_DIR = xbmc.translatePath('special://profile/addon_data/plugin.video.'+addon_name+'/')

#ACCOUNT INFO GLOBALS
TOKEN = my_addon.getSetting('token')
FORMAT = my_addon.getSetting('format')
ALLOW_EPG = my_addon.getSetting('epg')
EPG_DISPLAY = my_addon.getSetting('epg_display')
ACC = 0
ADULTS_LOCK = 0
ADULTS = 0
EXPIRE_IN=''
ACCOUNT_STATUS=''

def print_log(message):
    print("ACES_DEBUG: "+message)


if ALLOW_CACHE :
    try :   os.stat( xbmc.translatePath('special://profile/addon_data/plugin.video.'+addon_name))
    except:
        try : os.mkdir( xbmc.translatePath('special://profile/addon_data/plugin.video.'+addon_name))
        except : ALLOW_CACHE = 0




def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def get_from_portal(act,):

    url = PORTAL+"/api/iptv_account_v2.php?"+"token="+TOKEN+act;

    if ALLOW_CACHE :

        try :
            if time.time() > (os.path.getmtime(CACHE_DIR+act)+(60*10)) : force_error

            #f = open( CACHE_DIR+act+".cache" ,'r' )
            #data = json.loads(f.read())

            zip = zipfile.ZipFile(CACHE_DIR+act+".zip",'r')
            data = json.loads(zip.read(act))

        except :

            #f = open( CACHE_DIR+act+".cache" ,'w' )

            zip = zipfile.ZipFile(CACHE_DIR+act+".zip",'w',zipfile.ZIP_DEFLATED)

            response = urllib.urlopen(url)
            json_str = response.read()
            data = json.loads(json_str)

            zip.writestr(act,json_str)

            #f.write(json_str);
            #f.close();

    else :
        response = urllib.urlopen(url)
        json_str = response.read()
        data = json.loads(json_str)

    return data



if TOKEN == '' :
    itoken = xbmcgui.Dialog().input('Enter your account token', type=xbmcgui.INPUT_ALPHANUM)
    my_addon.setSetting('token', itoken)
    TOKEN = itoken


try :
    f = open( CACHE_DIR+"account.cache" ,'r' )
    data = json.loads(f.read())


    if time.time() > (os.path.getmtime(CACHE_DIR+"account.cache")+(60*10)) : force_error
    elif data['device_info']['token'] != TOKEN :
        if ALLOW_CACHE :
            shutil.rmtree(CACHE_DIR)
        force_error

except :


    url = PORTAL+"/api/iptv_account_v2.php?"+"token="+TOKEN+"&get_account_info"
    response = urllib.urlopen(url)
    json_str = response.read()
    retrive = json.loads(json_str)


    try : print (retrive['error_code'])


    except :
            ACC = 1
            ADULTS_LOCK=int(retrive['data']['adults_lock'])
            ADULTS=int(retrive['data']['allow_adults'])
            EXPIRE_IN = retrive['data']['expire_in'];
            if ALLOW_CACHE :
                f = open( CACHE_DIR+"account.cache" ,'w' )
                f.write(json_str)
                f.close()
    else :

            ACCOUNT_STATUS = retrive['error_message']
            xbmcgui.Dialog().ok('ACES PORTAL',str(retrive['error_message']))
            try: os.remove(CACHE_DIR+"account.cache")
            except: pass

else :
    f = open( CACHE_DIR+"account.cache" ,'r' )
    retrive = json.loads(f.read())
    ADULTS_LOCK=int(retrive['data']['adults_lock'])
    ADULTS=int(retrive['data']['allow_adults'])
    EXPIRE_IN = retrive['data']['expire_in'];
    ACC = 1
    ACCOUNT_STATUS = 'Active'




if mode is None:

    if ACC == 0 :

        li = xbmcgui.ListItem(ACCOUNT_STATUS, iconImage='DefaultVideo.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url='http://localhost', listitem=li)


    else :

        url = build_url({'mode': 'live_tv', 'foldername': 'Live TV', 'category': ' ' })
        li = xbmcgui.ListItem('Live TV', iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)


        url = build_url({'mode': 'videos', 'type': 'movies','list_by':0, 'genre':0, 'category':0})
        li = xbmcgui.ListItem('Movies', iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)


        url = build_url({'mode': 'series','list_by':' ', 'season': 0, 'series': 0})
        li = xbmcgui.ListItem('Series', iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)

        url = build_url({'mode': 'videos', 'type': 'replay','list_by':0, 'genre':0, 'category':0})
        li = xbmcgui.ListItem('Replays', iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)

        url = build_url({'mode': 'videos', 'type': 'documentaries','list_by':0, 'genre':0, 'category':0})
        li = xbmcgui.ListItem('Documentaries', iconImage='DefaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)

        if ADULTS :
            url = build_url({'mode': 'videos', 'type': 'adults','list_by':0, 'genre':0, 'category':0})
            li = xbmcgui.ListItem('Adults', iconImage='DefaultFolder.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)


    url = build_url({'mode': 'info', 'foldername': 'Account Info'})
    li = xbmcgui.ListItem('Account Info', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'clear' })
    li = xbmcgui.ListItem('Clear Cache', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)


    xbmcplugin.endOfDirectory(addon_handle)


elif mode[0] == 'live_tv' :

    cat = args['category'][0]

    if cat == ' ' :

        data = get_from_portal("&get_channels_categories")

        f_url = build_url({'mode': 'live_tv', 'category': '%ALL%'})
        li = xbmcgui.ListItem('All Streams', iconImage=LOGOS_DIR+'defaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f_url, listitem=li, isFolder=True)

        for i in data['data']:

            if not i['logo'] : logo = LOGOS_DIR+'defaultFolder.png'
            else :  logo = i['logo']

            try :
                f_url = build_url({'mode': 'live_tv', 'foldername': i['name'], 'category': i['name'] })
                li = xbmcgui.ListItem(i['name'], iconImage=logo)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=f_url, listitem=li, isFolder=True)
            except: pass



    else :

        #xbmc.executebuiltin( "Container.SetViewMode(%i)" % 504 )
        load_time = time.time()

        if cat == '%ALL%' : data = get_from_portal("&format="+FORMAT+"&get_channels&with_epg=1")
        else : data = get_from_portal("&format="+FORMAT+"&get_channels&category="+cat+"&with_epg=1")

        print_log(" LOAD TIME : "+ str( int(time.time()-load_time  ) ) )

        server_offset = int(data['server_time_offset'])


        for stream in data['data'] :


                #EPG INFO FROM SERVER IS ON SERVER TIME LET GET OFFSET.
                offset_to_apply = int(server_offset) - (((int(time.strftime('%z'))/100)*60)*60)

                chan_name = stream['name']

                lepg_info = []
                epg_info = None
                epg_desc = None
                show_programme = 0

                if not stream['logo'] : logo = LOGOS_DIR+'defaultFolder.png'
                else :  logo = stream['logo']


                if stream['epg'] != None and ALLOW_EPG == 'true' :


                    for e in stream['epg'] :


                        try :

                            if show_programme > MAX_PROGRAMME : break


                            tuple_start_time = time.strptime(str(e['start']),"%Y%m%d%H%M%S");
                            start_time = datetime.datetime.fromtimestamp( int(time.mktime(tuple_start_time)) - offset_to_apply ).strftime('%H:%M')
                            tuple_end_time = time.strptime(str(e['end']),"%Y%m%d%H%M%S");
                            end_time = datetime.datetime.fromtimestamp(int(time.mktime(tuple_end_time)) - offset_to_apply ).strftime('%H:%M')


                            #IF THIS PROGRAMME IS PLAYING ADD TO NAME
                            if (int(time.mktime(tuple_start_time)) - offset_to_apply) < time.time() and (int(time.mktime(tuple_end_time)) - offset_to_apply) > time.time() :
                                try :
                                    #chan_name = chan_name + " - [COLOR green]"+str(e['title'])+"[/COLOR]"
                                    lchan_name = []
                                    lchan_name.append(str(chan_name))
                                    lchan_name.append(" - [COLOR green]")
                                    lchan_name.append(str(e['title']))
                                    lchan_name.append("[/COLOR]")
                                    chan_name = ''.join(lchan_name)
                                    if EPG_DISPLAY == 'PROGRAMME_INFO'  or EPG_DISPLAY == 'BOTH' :
                                        try : str(e['title'])
                                        except : epg_desc = e['desc']
                                        else :
                                            epg_desc = "\n\n\n[COLOR green]"+str(e['title'])+"[/COLOR]\n"+str(e['desc'])

                                    show_programme = show_programme + 1

                                except : pass


                            if EPG_DISPLAY == 'NEXT_PROGRAMME' and (int(time.mktime(tuple_end_time)) - offset_to_apply) > time.time() or EPG_DISPLAY == 'BOTH' and  (int(time.mktime(tuple_end_time)) - offset_to_apply) > time.time() :

                                try : str(e['title'])
                                except : pass
                                else :
                                    lepg_info.append(start_time)
                                    lepg_info.append(' - ')
                                    lepg_info.append(end_time)
                                    lepg_info.append(' ')
                                    lepg_info.append(str(e['title']))
                                    lepg_info.append("\n")
                                    show_programme = show_programme + 1


                            if epg_desc :
                                lepg_info.append(epg_desc)


                            epg_info = ''.join(lepg_info).encode('utf-8')

                        except: pass




                ##IF IS AN ADULT CATEGORY AND ACCOUNT HAVE LOCK ON ADTULS CATEGORY WE NEED TO ASK FOR PASSWORD
                if stream['adults_category'] == 1 and ADULTS_LOCK :
                        f_url = build_url({'mode': 'load_adults', 'foldername': chan_name, 'url': stream['url']})
                        li = xbmcgui.ListItem(chan_name, iconImage=logo)
                        if epg_info :  li.setInfo('Video',  {'plot' : epg_info ,'title': chan_name } )
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f_url, listitem=li, isFolder=True)
                else :
                        li = xbmcgui.ListItem(chan_name, iconImage=logo)
                        if epg_info :  li.setInfo('Video',  {'plot' : epg_info ,'title': chan_name } )
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream['url'], listitem=li)


    xbmcplugin.endOfDirectory(addon_handle)



elif mode[0] == 'videos' :

    filter_genre = args['genre'][0]
    filter_cat = args['genre'][0]
    list_by = args['list_by'][0]
    otype = args['type'][0]


    if filter_genre == '0' and filter_cat == '0' and list_by == '0' and otype == 'movies' :

        retrive = get_from_portal("&get_videos_genres");

        f_url = build_url({'mode': 'videos', 'type': 'movies','list_by':'lastest', 'genre':0, 'category':0})
        li = xbmcgui.ListItem('Lastest Added', iconImage=LOGOS_DIR+'defaultFolder.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f_url, listitem=li, isFolder=True)

        for ganre_name in retrive['data']:

            f_url = build_url({'mode': 'videos', 'type': 'movies','list_by':0, 'genre':ganre_name, 'category':0})
            li = xbmcgui.ListItem(ganre_name, iconImage=LOGOS_DIR+'defaultFolder.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=f_url, listitem=li, isFolder=True)


    else :

        if list_by == 'lastest' : q = ''
        elif filter_genre != ' ' : q = "genre="+filter_genre
        elif filter_cat != ' ' : q = 'category='+filter_cat
        else : q=''


        data = get_from_portal("&get_videos&type="+otype+"&"+q)

        for stream in data['data']:

            #GETTING GENRES
            genres = str(stream['genre1'])
            if stream['genre2'] != '' : genres = genres + ", " + stream['genre2']
            if stream['genre3'] != '' : genres = genres + ', ' + stream['genre3']

            info = {
                'genre': genres,
                'year': stream['year'],
                'plot' : stream['about'],
                'title': stream['name'],
            }

            if not stream['logo'] : logo = LOGOS_DIR+'defaultFolder.png'
            else :  logo = stream['logo']


            ##IF IS AN ADULT CATEGORY AND ACCOUNT HAVE LOCK ON ADTULS CATEGORY WE NEED TO ASK FOR PASSWORD
            if stream['adults_category'] == 1 and ADULTS_LOCK :
                    f_url = build_url({'mode': 'load_adults', 'foldername': stream['name'], 'url': stream['url']})
                    li = xbmcgui.ListItem(stream['name'], iconImage=logo)
                    li.setInfo('Video', info)
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f_url, listitem=li, isFolder=True)
            else :
                    li = xbmcgui.ListItem(stream['name'], iconImage=logo)
                    li.setInfo('Video', info)
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream['url'], listitem=li)


    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'series' :

    series = args['series'][0]
    season = args['season'][0]

    #DISPLAYING SEASONS FROM SERIES SELECTED.

    if season != '0' :

        data = get_from_portal("&get_series&season="+season)

        for r in data['data'] :

            if not r['logo'] : logo = LOGOS_DIR+'defaultFolder.png'
            else : logo = r['logo']

            info = {
                'plot' : r['about'],
                'title': r['title'],
            }

            url = build_url({'mode': 'series','series':'0', 'season' : r['id'] })
            li = xbmcgui.ListItem(r['number']+". "+r['title'], iconImage=logo)
            li.setInfo('Video', info)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=r['url'], listitem=li)


    elif series != '0' :

        data = get_from_portal("&get_series&series="+series)

        for r in data['data'] :


            url = build_url({'mode': 'series','series':'0', 'season' : r['id'] })
            li = xbmcgui.ListItem("Season "+r['number'], iconImage='defaultFolder.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)


    else :

        data = get_from_portal("&get_series")

        for r in data['data'] :

            if not r['logo'] : logo = LOGOS_DIR+'defaultFolder.png'
            else : logo = r['logo']

            info = {
                'genre': r['genre1'],
                'year': r['year'],
                'plot' : r['about'],
                'title': r['name'],
            }

            url = build_url({'mode': 'series','series':r['id'], 'season' : '0' })
            li = xbmcgui.ListItem(r['name'], iconImage=logo)
            li.setInfo('Video', info)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)



    xbmcplugin.endOfDirectory(addon_handle)


elif mode[0] == 'load_adults' :

    pin = xbmcgui.Dialog().input('Enter Your PIN', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    url = args['url'][0] + "?pin="+pin
    listItem = xbmcgui.ListItem("Play", path=url)
    xbmc.Player().play(item=url, listitem=listItem)


elif mode[0] == 'info':
    retrive = get_from_portal("&get_account_info")
    if retrive['status'] == 'error' :
        status = 'expired'
        expire_in = '0'
    else :
        status = retrive['data']['status']
        expire_in = retrive['data']['expire_in']+ " Days"
    xbmcgui.Dialog().ok("ACCOUNT INFO","ACCOUNT STATUS : "+status+"\nACCOUNT EXPIRE ON : "+expire_in)

elif mode[0] == 'clear' :
    filelist = [ f for f in os.listdir(CACHE_DIR) if f.endswith(".cache") ]
    for f in filelist:
        os.remove(CACHE_DIR+f)
    xbmc.executebuiltin("Notification(Cache Removed,)")

